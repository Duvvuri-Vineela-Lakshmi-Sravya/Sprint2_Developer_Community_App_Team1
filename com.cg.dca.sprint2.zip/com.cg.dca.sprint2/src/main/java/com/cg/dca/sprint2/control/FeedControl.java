package com.cg.dca.sprint2.control;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.cg.dca.sprint2.exception.UnknownFeedException;
import com.cg.dca.sprint2.model.Feed;
import com.cg.dca.sprint2.service.FeedService;

//used to implement web application
@Controller
@RequestMapping("/feed")
public class FeedControl
{
	
	@Autowired
	FeedService feedService;
	
	/*List of all Feeds*/
	
	@GetMapping(value = {"/" })
	public @ResponseBody List<Feed> getAllFeeds() 
	{ 
		List<Feed> feeds = feedService.getAllfeeds();
		return feeds;
	}
	
	/*Add Feed*/
	
	@PostMapping("/")
	public @ResponseBody Feed addFeed(@RequestBody Feed feed) 
	{
		return feedService.addfeed(feed);
	}
	
	/*Update Feed*/
	
	@PutMapping("/")
	public ResponseEntity<Feed> updateFeed(@RequestBody Feed feed) 
	{
		Optional<Feed> feed2 = feedService.getFeedById((feed.getFeedId()));
		if (!feed2.isPresent()) {
		throw new UnknownFeedException("No Feed with id : " + feed.getFeedId() + " is found to update");
		}
		feedService.updateFeed(feed);
		return new ResponseEntity<Feed>(feed, HttpStatus.OK);
	}
	
	/*Delete Feed*/
	
	@DeleteMapping("/feed/{id}")
	public ResponseEntity<String>removeFeed(@PathVariable int id) //method parameter should be bound to a URI template variable
	{
		Optional<Feed> feed1 = feedService.getFeedById(id);
		System.out.println(feed1);
		if (!feed1.isPresent()) {
		throw new UnknownFeedException("No feed found  with id : " + id + " to delete");
		}
		String str1=feedService.removeFeed(id);
		return new ResponseEntity<String>(str1,HttpStatus.OK);
	}

	/*Get Feed By Topic*/
	
	@GetMapping("/f/{topic}")
	public ResponseEntity<List<Feed>> getFeedByTopic(@PathVariable String topic) 
	{
		
		List<Feed>f1=feedService.getFeedByTopic(topic);
		if(f1.isEmpty())
		{
			throw new UnknownFeedException("Feed not found with given topic");
		}
		return new ResponseEntity<List<Feed>>(f1,HttpStatus.OK);
	}
	
	/*Get Feed by Keyword*/
	
	@GetMapping("/key/{keyword}")
	public ResponseEntity<List<Feed>> getFeedByKeyword(@PathVariable String keyword) 
	{
		List<Feed>f =feedService.getFeedByKeyword(keyword);
		if(f.isEmpty())
		{
			throw new UnknownFeedException("Feed not found with given keyword");
		}
		return new ResponseEntity<List<Feed>>(f,HttpStatus.OK);
	}
	
	/*Get Feed By Id*/
	
	@GetMapping("{id}")
	public ResponseEntity<Feed> getFeedById(@PathVariable int id)
	{
		Optional<Feed> feed = feedService.getFeedById(id);
		if (!feed.isPresent()) 
		{
			throw new UnknownFeedException("Feed not found with the given id");
		}
		return new ResponseEntity<Feed>(feed.get(), HttpStatus.OK);
	
	}

}