package com.cg.dca.sprint2.control;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.dca.sprint2.model.Developer;



public interface IDeveloperControl {
	public List<Developer> getAllDevelopers();
	public ResponseEntity<Developer> getDeveloperById(@PathVariable int id);
	public Developer addDeveloper(@RequestBody Developer developer);
	public ResponseEntity<Developer> updateDeveloper(@RequestBody Developer developer);
	public ResponseEntity<String> removeDeveloper(@PathVariable int id);

}
