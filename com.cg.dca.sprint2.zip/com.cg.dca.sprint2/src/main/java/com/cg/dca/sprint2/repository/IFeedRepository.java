package com.cg.dca.sprint2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.dca.sprint2.model.Feed;


@Repository
public interface IFeedRepository extends JpaRepository<Feed, Integer>{

	List<Feed> findAll();  // jpa repository includes all the methods 
}
