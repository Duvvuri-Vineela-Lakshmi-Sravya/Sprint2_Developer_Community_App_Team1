package com.cg.dca.sprint2.control;

	import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.dca.sprint2.model.Admin;

	public interface IAdminControl {
		
		public @ResponseBody Admin addAdmin(@RequestBody Admin admin);
		
		public @ResponseBody List<Admin> getAllAdmin();
		
		public ResponseEntity<Admin> getAdminById(@PathVariable int id);
		
		public ResponseEntity<Admin> updateAdmin(@RequestBody Admin admin);
		
		public ResponseEntity<String> deleteAdminbyId(@PathVariable int id);
		
	}

