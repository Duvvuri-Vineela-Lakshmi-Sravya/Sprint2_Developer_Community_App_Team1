package com.cg.dca.sprint2.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dca.sprint2.model.Admin;
import com.cg.dca.sprint2.repository.IAdminRepository;

@Service
public class AdminService implements IAdminService{
	@Autowired
	private IAdminRepository adminRepository;
	/*Get Admin by Id*/
	public Optional<Admin>getAdminById(int id) {
		
			return adminRepository.findById(id);
		
	}
	/*Add Admin */
	public Admin addAdmin(Admin admin)
	{
		return adminRepository.save(admin);
	
	}
	/*Update Admin*/
	public Admin updateAdmin(Admin admin) 
	{
		return adminRepository.save(admin);
	}
	
	/*Delete Admin*/
	public String deleteAdminbyId(int id)
	{
		adminRepository.deleteById(id);
		return "Admin with "+id+" deleted successfully";
		
	}
	/*Display all the admin*/
	@Override
	public List<Admin> getAllAdmin() {
		return adminRepository.findAll();
	}
}