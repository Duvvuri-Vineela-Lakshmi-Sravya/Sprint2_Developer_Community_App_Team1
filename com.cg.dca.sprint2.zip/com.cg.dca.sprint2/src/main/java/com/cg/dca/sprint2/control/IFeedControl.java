package com.cg.dca.sprint2.control;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.dca.sprint2.model.Feed;



public interface IFeedControl {
	
	public @ResponseBody List<Feed> getAllFeeds();
	
	public @ResponseBody Feed addFeed(@RequestBody Feed feed);
	
	public ResponseEntity<Feed> updateFeed(@RequestBody Feed feed);
	
	public ResponseEntity<String>removeFeed(@PathVariable int id);
	
	public ResponseEntity<List<Feed>> getFeedByTopic(@PathVariable String topic);
	
	public ResponseEntity<List<Feed>> getFeedByKeyword(@PathVariable String keyword); 
	
	public ResponseEntity<Feed> getFeedById(@PathVariable int id);

}
