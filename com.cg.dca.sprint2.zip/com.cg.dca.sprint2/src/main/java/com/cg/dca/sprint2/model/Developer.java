package com.cg.dca.sprint2.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table
public class Developer {

	@Id
	@GeneratedValue
	private int devId;
	private String name;
	private String email;
	private String skillLevel;	// Beginner/Intermediate/Expert
	private LocalDate memberSince;
	@JsonFormat
	@OneToOne(cascade=CascadeType.ALL)
	private Users users;
	@JsonFormat
	@OneToMany(cascade=CascadeType.ALL)
	@JsonIgnore
	private List<Feed> feeds;
	private int totalFeeds;	
	private int reputation;		// Likes on Feed/Response by developer increase reputation
	private boolean isVerified;
	private boolean isBlocked;
	
	
	//constructor without Id
	public Developer(String name, String email, String skillLevel, LocalDate memberSince, Users users, List<Feed> feeds,
			int totalFeeds, int reputation, boolean isVerified, boolean isBlocked) {
		super();
		this.name = name;
		this.email = email;
		this.skillLevel = skillLevel;
		this.memberSince = memberSince;
		this.users = users;
		this.feeds = feeds;
		this.totalFeeds = totalFeeds;
		this.reputation = reputation;
		this.isVerified = isVerified;
		this.isBlocked = isBlocked;
	}
	//Default Constructor
	public Developer() {
		super();
	}
	//Constructor with Id
	public Developer(int devId, String name, String email, String skillLevel, LocalDate memberSince, Users users,
			List<Feed> feeds, int totalFeeds, int reputation, boolean isVerified, boolean isBlocked) {
		super();
		this.devId = devId;
		this.name = name;
		this.email = email;
		this.skillLevel = skillLevel;
		this.memberSince = memberSince;
		this.users = users;
		this.feeds = feeds;
		this.totalFeeds = totalFeeds;
		this.reputation = reputation;
		this.isVerified = isVerified;
		this.isBlocked = isBlocked;
	}
	public int getDevId() {
		return devId;
	}
	public void setDevId(int devId) {
		this.devId = devId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSkillLevel() {
		return skillLevel;
	}
	public void setSkillLevel(String skillLevel) {
		this.skillLevel = skillLevel;
	}
	public LocalDate getMemberSince() {
		return memberSince;
	}
	public void setMemberSince(LocalDate memberSince) {
		this.memberSince = memberSince;
	}
	public int getTotalFeeds() {
		return totalFeeds;
	}
	public void setTotalFeeds(int totalFeeds) {
		this.totalFeeds = totalFeeds;
	}
	public int getReputation() {
		return reputation;
	}
	public void setReputation(int reputation) {
		this.reputation = reputation;
	}
	public boolean isVerified() {
		return isVerified;
	}
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}
	public boolean isBlocked() {
		return isBlocked;
	}
	public void setBlocked(boolean isBlocked) {
		this.isBlocked = isBlocked;
	}
	@Override
	public String toString() {
		return "Developer [devId=" + devId + ", name=" + name + ", email=" + email + ", skillLevel=" + skillLevel
				+ ", memberSince=" + memberSince + ", totalFeeds=" + totalFeeds + ", reputation=" + reputation
				+ ", isVerified=" + isVerified + ", isBlocked=" + isBlocked + "]";
	}
	
}
