package com.cg.dca.sprint2.service;
import java.util.List;
import java.util.Optional;

import com.cg.dca.sprint2.model.Admin;
import com.cg.dca.sprint2.model.Developer;



	public interface IAdminService {

		Admin addAdmin(Admin admin);
		
		Optional<Admin> getAdminById(int id);

		List<Admin> getAllAdmin();

		String deleteAdminbyId(int id);

		Admin updateAdmin(Admin admin);
	}
