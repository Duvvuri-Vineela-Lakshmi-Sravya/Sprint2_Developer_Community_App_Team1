package com.cg.dca.sprint2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dca.sprint2.model.Feed;
import com.cg.dca.sprint2.repository.IFeedRepository;

@Service
public class FeedService{
	
	@Autowired
	 IFeedRepository feedRepository;

	//Getting all the feeds from the user
	public List<Feed> getAllfeeds() {
		System.out.println("-----Feeds-----");
		return feedRepository.findAll();
	}

	// feed by specific topic
	public List<Feed> getFeedByTopic(String topic) {
		List<Feed> feed=new ArrayList<Feed>();
		feedRepository.findAll().forEach(feed1->feed.add(feed1));
		List<Feed> feedBasedonTopic=new ArrayList<Feed>();
		for(Feed f:feed)
		{
			if(f.getTopic().equalsIgnoreCase(topic))
				feedBasedonTopic.add(f);	
		}
		return feedBasedonTopic;
	}

	//feed by specific keyword from the query
	public List<Feed> getFeedByKeyword(String keyword) {
		List<Feed> feed=feedRepository.findAll();
		List<Feed> feedBasedonKeyword=new ArrayList<Feed>();
		for(Feed h:feed)
		{
			if(h.getQuery().equalsIgnoreCase(keyword))
				feedBasedonKeyword.add(h);	
		}
			return feedBasedonKeyword;
	}
	

	//Adding feed to the database
	public Feed addfeed(Feed feed) {
		System.out.println("Feed added successfully.");
		return feedRepository.save(feed);
	}

	//updating the feed
	public Feed updateFeed(Feed feed) {
		return feedRepository.save(feed);
	}

	//deleting the feed
	public String removeFeed(int id) {
		System.out.println("Feed removed successfully.");
		feedRepository.deleteById(id);
		return "Feed with "+id+" deleted Sucessfully";
	}
	// Get Feed By Id
	public Optional<Feed> getFeedById(int id) {
		
		return feedRepository.findById(id);
	}

}
