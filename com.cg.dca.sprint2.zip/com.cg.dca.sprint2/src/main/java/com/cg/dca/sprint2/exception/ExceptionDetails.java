package com.cg.dca.sprint2.exception;

import java.time.LocalDate;


public class ExceptionDetails {

	private LocalDate timestamp;
    private String message;
    private String details;
	public ExceptionDetails(LocalDate timestamp, String message, String details) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.details = details;
	}
	public ExceptionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	// When exception has occured
	
	public LocalDate getTimestamp() 
	{
		return timestamp;
	}
	public void setTimestamp(LocalDate timestamp) 
	{
		this.timestamp = timestamp;
	}
	
	//Relevant message is displayed based on Exception
	
	public String getMessage() 
	{
		return message;
	}
	
	public void setMessage(String message) 
	{
		this.message = message;
	}
	
	//Details related to Exception
	
	public String getDetails() 
	{
		return details;
	}
	
	public void setDetails(String details) 
	{
		this.details = details;
	}
}