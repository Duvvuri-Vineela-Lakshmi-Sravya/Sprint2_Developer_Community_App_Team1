package com.cg.dca.sprint2.control;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dca.sprint2.exception.UnknownDeveloperException;
import com.cg.dca.sprint2.exception.UnknownFeedException;
import com.cg.dca.sprint2.exception.UnknownUserException;
import com.cg.dca.sprint2.model.Developer;
import com.cg.dca.sprint2.model.Feed;
import com.cg.dca.sprint2.model.Users;
import com.cg.dca.sprint2.service.IUserService;


@RestController
@RequestMapping("/users")   // Creating an end point for user
public class UserControl implements IUserControl {

	// Usage of services
	@Autowired
	IUserService userService;
	
	
	// To add new User
	@PostMapping("/")
	public @ResponseBody String insertUser(@RequestBody Users users)
	{
		userService.addUser(users);
		return users.getUserId();
	}
	
	// To get all the users
	@GetMapping("/")
	public @ResponseBody List<Users> getAllUsers()
	{
		return userService.getAllUsers();
	}
	
	// To delete user 
	@DeleteMapping("/{userId}")
	
	public ResponseEntity<String> deleteUser(@PathVariable("userId") String id)
	{
		List<Users> user1 = userService.getUserById(id);
		System.out.println(user1);
		if (user1.isEmpty()) {
		throw new UnknownUserException("No user found  with id : " + id + " to delete");
		}
		String str=userService.deleteUser(id);
		return new ResponseEntity<String>(str,HttpStatus.OK);
	}
	
	// To edit user details like password, userId or role.
	@PutMapping("/")
	public ResponseEntity<Users> updateUser(@RequestBody Users users)         //response entity 
	{
		List<Users> uObj = userService.getUserById((users.getUserId()));
		if (!uObj.isEmpty()) 
		{
			throw new UnknownDeveloperException("Not found user with id : " + users.getUserId() + " to update");
		}
		Users u =userService.updateUser(users);
		return new ResponseEntity<Users>(u, HttpStatus.OK);
	}
	
	// To logout from the application.
	@GetMapping("/logout")
	public String logout(Users users)
	{
		return userService.logout(users);
	}
	
	@GetMapping("/login")
	public String login(Users login)
	{
		return userService.login(login);
		
	}
	@GetMapping("{id}")
	public ResponseEntity<Users> getUserById(@PathVariable String id)
	{
		List<Users> user = userService.getUserById(id);
		if (user.isEmpty())
		{
			throw new UnknownUserException("User not found with the given id");
		}
		return new ResponseEntity<Users>(user.get(0), HttpStatus.OK);
	
	}

}
