package com.cg.dca.sprint2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dca.sprint2.model.Response;
import com.cg.dca.sprint2.repository.IResponseRepository;

@Service
public class ResponseService {
	
	@Autowired
	private IResponseRepository responseRepository;

	//Getting all the feeds from the user
	public List<Response> getAllresponses() {
		System.out.println("-----Responses-----");
		return responseRepository.findAll();
	}
	
	public Response addresponse(Response response) {
		System.out.println("Response added successfully.");
		return responseRepository.save(response);
	}

	public Response updateResponse(Response response) {
		return responseRepository.save(response);
	}

	public String removeResponse(int id) 
	{
		System.out.println(" Response removed successfully.");
		responseRepository.deleteById(id);
		return "Response with "+id+"deleted Sucessfully";
	}
	
	public Optional<Response> getResponseById(int id) 
	{
		return responseRepository.findById(id);
	}

}
