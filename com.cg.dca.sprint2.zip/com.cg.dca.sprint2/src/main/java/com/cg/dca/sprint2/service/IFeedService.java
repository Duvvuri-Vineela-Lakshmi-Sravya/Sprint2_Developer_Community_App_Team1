package com.cg.dca.sprint2.service;

import java.util.List;
import java.util.Optional;
import com.cg.dca.sprint2.model.Feed;


public interface IFeedService {
	
	List<Feed> getAllfeeds();
	
	Optional<Feed> getFeedById(int id);
	
	List<Feed> getFeedByTopic(String topic);
	
	List<Feed> getFeedByKeyword(String keyword);
	
	Feed addfeed(Feed feed);
	
	Feed updateFeed(Feed feed);
	
	String removeFeed(int id);

}
