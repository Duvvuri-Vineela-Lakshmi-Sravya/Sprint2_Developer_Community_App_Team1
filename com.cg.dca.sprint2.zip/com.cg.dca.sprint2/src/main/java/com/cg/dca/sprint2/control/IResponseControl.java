package com.cg.dca.sprint2.control;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.dca.sprint2.model.Response;


public interface IResponseControl {

	public @ResponseBody List<Response> getAllResponses();
	
	public @ResponseBody Response addResponse(@RequestBody Response response);
	
	public ResponseEntity<Response> updateResponse(@RequestBody Response response);
	
	public ResponseEntity<Response> getResponseById(@PathVariable int id);
	
	public ResponseEntity<String> removeResponse(@PathVariable int id);
}
