package com.cg.dca.sprint2.control;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.dca.sprint2.model.Users;


public interface IUserControl {
	
	public @ResponseBody String insertUser(@RequestBody Users users);
	
	public @ResponseBody List<Users> getAllUsers();
	
	public @ResponseBody ResponseEntity<String> deleteUser(@PathVariable("userId") String id);
	
	public @ResponseBody ResponseEntity<Users> updateUser(@RequestBody Users user);
	
	public String logout(Users user);
	
	public String login(Users users);

}