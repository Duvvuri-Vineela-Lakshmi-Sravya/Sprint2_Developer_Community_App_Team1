package com.cg.dca.sprint2.service;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dca.sprint2.model.Developer;
import com.cg.dca.sprint2.repository.IDeveloperRepository;


@Service
public class DeveloperService implements IDeveloperService
{
	@Autowired
	private IDeveloperRepository devrep;
	
	        /*To get all the developers */
	
	public List<Developer> getAllDeveloper() 
	{
		List<Developer> li = devrep.findAll();
		return li;
	}
	
	         /*To get Developer by Id*/
	
	public Optional<Developer> getDeveloperById(int devId) 
	{
		return devrep.findById(devId);
	}
	/*Add Developer*/
	
	public Developer addDeveloper(Developer Developer) 
	{
		System.out.println("Developer added.");
			return devrep.save(Developer);

	}
	/*update Developer*/
	
	public Developer updateDeveloper(Developer Developer) 
	{
		
			return devrep.save(Developer);
	}
	
	
	/*Remove Developer*/
	
	public String removeDeveloper(int id) 
	{
		System.out.println("Developer removed.");
		devrep.deleteById(id);
		return "Developer with "+id+" deleted Successfully";
	}

}