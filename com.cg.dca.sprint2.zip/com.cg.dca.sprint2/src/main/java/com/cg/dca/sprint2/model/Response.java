package com.cg.dca.sprint2.model;


import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Response {
	@Id
	@GeneratedValue   //Id is primary key here
	private int id;
	private String answer;
	private LocalDate respDate;
	 @JsonFormat(pattern="HH:mm")
	private LocalTime respTime;
	private int accuracy;
	@JsonFormat
	@OneToOne(cascade=CascadeType.ALL)
	private Developer developer;
	@JsonFormat
	@OneToOne(cascade=CascadeType.ALL)
	private Feed feed;

	

	
	// Constructor with Id
	public Response(String answer, LocalDate respDate, LocalTime respTime, int accuracy, Developer developer,
			Feed feed) {
		super();
		this.answer = answer;
		this.respDate = respDate;
		this.respTime = respTime;
		this.accuracy = accuracy;
		this.developer = developer;
		this.feed = feed;
	}
	// Default Constructor
	public Response() {
		super();
	}
	// Constructor with Id
	public Response(int id, String answer, LocalDate respDate, LocalTime respTime, int accuracy, Developer developer,
			Feed feed) {
		super();
		this.id = id;
		this.answer = answer;
		this.respDate = respDate;
		this.respTime = respTime;
		this.accuracy = accuracy;
		this.developer = developer;
		this.feed = feed;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public LocalDate getRespDate() {
		return respDate;
	}

	public void setRespDate(LocalDate respDate) {
		this.respDate = respDate;
	}

	public LocalTime getRespTime() {
		return respTime;
	}

	public void setRespTime(LocalTime respTime) {
		this.respTime = respTime;
	}

	public int getAccuracy() {
		return accuracy;
	}

	public void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}

	@Override
	public String toString() {
		return "Response [id=" + id + ", answer=" + answer + ", respDate=" + respDate + ", respTime=" + respTime
				+ ", accuracy=" + accuracy + "]";
	}


}
