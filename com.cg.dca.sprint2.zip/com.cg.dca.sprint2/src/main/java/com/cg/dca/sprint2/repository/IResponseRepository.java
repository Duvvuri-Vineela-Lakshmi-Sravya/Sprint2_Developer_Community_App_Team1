package com.cg.dca.sprint2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.dca.sprint2.model.Response;


@Repository
public interface IResponseRepository extends JpaRepository<Response, Integer> {
	List<Response> findAll(); 
	

}
