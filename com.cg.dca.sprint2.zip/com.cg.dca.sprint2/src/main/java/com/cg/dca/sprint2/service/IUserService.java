package com.cg.dca.sprint2.service;

import java.util.List;
import java.util.Optional;

import com.cg.dca.sprint2.model.Users;


public interface IUserService {

	void addUser(Users users);

	List<Users> getAllUsers();

	String deleteUser(String id);

	Users updateUser(Users users);

	String logout(Users users);

	String login(Users users);

	List<Users> getUserById(String id);

}
