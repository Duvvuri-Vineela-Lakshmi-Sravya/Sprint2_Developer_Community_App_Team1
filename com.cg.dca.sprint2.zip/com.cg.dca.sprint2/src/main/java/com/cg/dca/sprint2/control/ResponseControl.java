package com.cg.dca.sprint2.control;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.cg.dca.sprint2.exception.UnknownResponseException;
import com.cg.dca.sprint2.model.Response;
import com.cg.dca.sprint2.service.ResponseService;



@Controller
@RequestMapping("/response")
public class ResponseControl{
		
	@Autowired
	private ResponseService responseService;
		
	/*Get all responses*/
	
	@GetMapping(value = {"/" })
	public @ResponseBody List<Response> getAllResponses() 
	{ 
		List<Response> responses = responseService.getAllresponses();
		return responses;
	}
	
	/*Add Responses*/
	
	@PostMapping("/")
	public @ResponseBody Response addResponse(@RequestBody Response response) 
	{
		return  responseService.addresponse(response);
	}
	
	/*Update Response*/
	
	@PutMapping("/")
	public ResponseEntity<Response> updateResponse(@RequestBody Response response) 
	{
		
		Optional<Response> response1 = responseService.getResponseById((response.getId()));
		if (!response1.isPresent()) 
		{
			throw new UnknownResponseException("Not found response with id : " + response.getId() + " to update");
		}
		responseService.updateResponse(response);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	/*Delete Response*/
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> removeResponse(@PathVariable int id) 
	{
		Optional<Response> response2 = responseService.getResponseById(id);
		System.out.println(response2);
		if (!response2.isPresent())
		{
			throw new UnknownResponseException("No response found  with id : " + id + " to delete");
		}
		String str=responseService.removeResponse(id);
		return new ResponseEntity<String>(str,HttpStatus.OK);
	}
	
	/*Get response By Id*/
	
	@GetMapping("/{id}")
	public ResponseEntity<Response> getResponseById(@PathVariable int id) 
	{
		
		Optional<Response> response = responseService.getResponseById(id);
		if (!response.isPresent()) 
		{
			throw new UnknownResponseException("Response not found with the given id");
		}
		return new ResponseEntity<Response>(response.get(), HttpStatus.OK);
	}
}