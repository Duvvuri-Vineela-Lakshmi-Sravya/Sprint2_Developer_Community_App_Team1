package com.cg.dca.sprint2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dca.sprint2.exception.UnknownUserException;
import com.cg.dca.sprint2.model.Users;
import com.cg.dca.sprint2.repository.IUserRepository;


@Service
public class UserService implements IUserService{
	
	@Autowired
	IUserRepository userRepository;

	public void addUser(Users users) {
		userRepository.save(users);
	}

	public List<Users> getAllUsers() {
		List<Users> users=userRepository.findAll();
		return users;
		
	}
	public String deleteUser(String id) {
		userRepository.deleteById(id);		
		return "user with "+id+" deleted successfully";
	}
	public Users updateUser(Users users) {
		return userRepository.save(users);
	}

	public String logout(Users users) {
		String s=users.getUserId()+" has successfully logged out";
		return s;
	}

	public String login(Users users) {
		String userID=users.getUserId();
		String str1=null;
		List<Users> li=getUserById(userID);
		if(li==null)
		{
			
			str1="Please enter correct details";
			
		}
		else
		{
			for(Users u :li)
			{
				String pwd=u.getPassword();
				String role = u.getRole();
				if(pwd.equals(users.getPassword()) && role.equalsIgnoreCase(users.getRole()))
				{
					str1=u.getUserId()+" has successfully logged in";
				}
			}
			
		}
		return str1;
	}

	public List<Users> getUserById(String id) {
		List<Users> user=userRepository.findAll();
		List<Users> s = new ArrayList<Users>();
		for(Users u: user)
		{
			if(u.getUserId().equals(id))
			{
				s.add(u);
			}
		}
		
		return s;
	}
}
