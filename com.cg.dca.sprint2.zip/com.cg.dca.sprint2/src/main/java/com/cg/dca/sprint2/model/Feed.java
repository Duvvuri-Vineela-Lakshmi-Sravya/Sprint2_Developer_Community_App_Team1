package com.cg.dca.sprint2.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Feed {
	@Id
	@GeneratedValue   //Id is primary key here
	private int feedId;
	private String query;
	private LocalDate feedDate;
	 @JsonFormat(pattern="HH:mm")
	private LocalTime feedTime;
	 private String topic;	
	 private int relevance;    
	 @JsonFormat
	 @ManyToOne(cascade=CascadeType.ALL)
	 private Developer developer;
	 @JsonFormat
	 @OneToMany(cascade=CascadeType.ALL)
	 @JsonIgnore
	 private List<Response> responses;
	private int totalComments;
	
	
	// Default Constructor
	public Feed() {
		super();
	}
	// Constructor without Id
	public Feed(String query, LocalDate feedDate, LocalTime feedTime, String topic, int relevance, Developer developer,
			List<Response> responses, int totalComments) {
		super();
		this.query = query;
		this.feedDate = feedDate;
		this.feedTime = feedTime;
		this.topic = topic;
		this.relevance = relevance;
		this.developer = developer;
		this.responses = responses;
		this.totalComments = totalComments;
	}
	// Constructor with Id
	public Feed(int feedId, String query, LocalDate feedDate, LocalTime feedTime, String topic, int relevance,
			Developer developer, List<Response> responses, int totalComments) {
		super();
		this.feedId = feedId;
		this.query = query;
		this.feedDate = feedDate;
		this.feedTime = feedTime;
		this.topic = topic;
		this.relevance = relevance;
		this.developer = developer;
		this.responses = responses;
		this.totalComments = totalComments;
	}
	public int getFeedId() {
		return feedId;
	}
	public void setFeedId(int feedId) {
		this.feedId = feedId;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public LocalDate getFeedDate() {
		return feedDate;
	}
	public void setFeedDate(LocalDate feedDate) {
		this.feedDate = feedDate;
	}
	public LocalTime getFeedTime() {
		return feedTime;
	}
	public void setFeedTime(LocalTime feedTime) {
		this.feedTime = feedTime;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public int getRelevance() {
		return relevance;
	}
	public void setRelevance(int relevance) {
		this.relevance = relevance;
	}
	public int getTotalComments() {
		return totalComments;
	}
	public void setTotalComments(int totalComments) {
		this.totalComments = totalComments;
	}
	@Override
	public String toString() {
		return "Feed [feedId=" + feedId + ", query=" + query + ", feedDate=" + feedDate + ", feedTime=" + feedTime
				+ ", topic=" + topic + ", relevance=" + relevance + ", totalComments=" + totalComments + "]";
	}

	


}
