package com.cg.dca.sprint2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.dca.sprint2.model.Developer;

@Repository
public interface IDeveloperRepository extends JpaRepository<Developer,Integer> 
{
	
}
