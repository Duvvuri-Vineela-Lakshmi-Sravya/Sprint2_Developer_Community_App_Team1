package com.cg.dca.sprint2.control;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dca.sprint2.exception.UnknownDeveloperException;
import com.cg.dca.sprint2.model.Developer;
import com.cg.dca.sprint2.service.DeveloperService;

@RestController
@RequestMapping("developer")
public class DeveloperControl
{
	@Autowired
	DeveloperService developerService;
	
	/*Get all Developers*/
	@GetMapping("")
	public List<Developer> getAllDevelopers()
	{
		return developerService.getAllDeveloper();
	}
	
	/*Get Developer By Id*/
	
	@GetMapping("{id}")
	public ResponseEntity<Developer> getDeveloperById(@PathVariable int id)
	{
		Optional<Developer> developer = developerService.getDeveloperById(id);
		if (!developer.isPresent()) 
		{
			throw new UnknownDeveloperException("Developer not found with the given id");
		}
		return new ResponseEntity<Developer>(developer.get(), HttpStatus.OK);
	
	}
	
	/* Add Developer*/
	
	@PostMapping("")
	public Developer addDeveloper(@RequestBody Developer developer)
	{
		return developerService.addDeveloper(developer);
	}
	
	/*Update Developer*/
	
	@PutMapping("")
	public ResponseEntity<Developer> updateDeveloper(@RequestBody Developer developer)
	{
	
		Optional<Developer> devObj = developerService.getDeveloperById((developer.getDevId()));
		if (!devObj.isPresent()) 
		{
			throw new UnknownDeveloperException("Not found developer with id : " + developer.getDevId() + " to update");
		}
		developerService.updateDeveloper(developer);
		return new ResponseEntity<Developer>(developer, HttpStatus.OK);
	}
	
	/*Delete Developer*/
	
	@DeleteMapping("{id}")
	public ResponseEntity<String> removeDeveloper(@PathVariable int id)
	{
	
		Optional<Developer> dev = developerService.getDeveloperById(id);
		System.out.println(dev);
		if (!dev.isPresent())
		{
			throw new UnknownDeveloperException("No Developer found  with id : " + id + " to delete");
		}
		String str=developerService.removeDeveloper(id);
		return new ResponseEntity<String>(str,HttpStatus.OK);
	}
}