package com.cg.dca.sprint2.service;

import java.util.List;
import java.util.Optional;

import com.cg.dca.sprint2.model.Developer;



public interface IDeveloperService 
{
	List<Developer> getAllDeveloper();
	Optional<Developer> getDeveloperById(int devId);
	Developer addDeveloper(Developer Developer);
	Developer updateDeveloper(Developer Developer);
	String removeDeveloper(int id);
}
