package com.cg.dca.sprint2.control;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.dca.sprint2.exception.UnknownAdminException;
import com.cg.dca.sprint2.exception.UnknownDeveloperException;
import com.cg.dca.sprint2.model.Admin;
import com.cg.dca.sprint2.service.AdminService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;


@Controller
@RequestMapping("/admin")
public class AdminControl implements IAdminControl
{
	@Autowired
	private AdminService adminService;
	
	/* Get All Admin's*/
	
	@GetMapping({"/"})
	public @ResponseBody List<Admin> getAllAdmin()
	{
		return adminService.getAllAdmin();
		
	}
	
	//Get Admin By Id
	
	@GetMapping("/{id}")
	public ResponseEntity<Admin> getAdminById(@PathVariable int id)
	{
		Optional<Admin> admin = adminService.getAdminById(id);
		if (!admin.isPresent()) 
		{
			throw new UnknownAdminException("Admin not found with the given id");
		}
		return new ResponseEntity<Admin>(admin.get(), HttpStatus.OK);
	
	}
	
	/*Add Admin*/
	
	@PostMapping("/")
	public @ResponseBody Admin addAdmin(@RequestBody Admin admin)
	{
		return adminService.addAdmin(admin);
	}
	
	/*Update Admin*/
	
	@PutMapping("/")
	public ResponseEntity<Admin> updateAdmin(@RequestBody Admin admin)
	{
	
		Optional<Admin> adObj = adminService.getAdminById((admin.getId()));
		if (!adObj.isPresent()) 
		{
			throw new UnknownAdminException("Not found Admin with id : " + admin.getId() + " to update");
		}
		adminService.updateAdmin(admin);
		return new ResponseEntity<Admin>(admin, HttpStatus.OK);
	}
	
	/*Delete admin*/
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteAdminbyId(@PathVariable int id)
	{
	
		Optional<Admin> ad = adminService.getAdminById(id);
		System.out.println(ad);
		if (!ad.isPresent())
		{
			throw new UnknownAdminException("Not Admin found  with id : " + id + " to delete");
		}
		String str1=adminService.deleteAdminbyId(id);
		return new ResponseEntity<String>(str1,HttpStatus.OK);
	}
}
