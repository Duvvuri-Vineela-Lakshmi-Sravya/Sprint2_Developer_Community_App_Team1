package com.cg.dca.sprint2;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.cg.dca.sprint2.control.DeveloperControl;
import com.cg.dca.sprint2.model.Developer;
import com.cg.dca.sprint2.model.Feed;
import com.cg.dca.sprint2.model.Response;
import com.cg.dca.sprint2.model.Users;
import com.cg.dca.sprint2.repository.IDeveloperRepository;
import com.cg.dca.sprint2.service.DeveloperService;



@ExtendWith(MockitoExtension.class)
public class TestDeveloperService {
	@Mock
	IDeveloperRepository devRep;
	

	@InjectMocks
	DeveloperService devSer;
	
	
	
	/*public Feed(long feedId, String query, LocalDate feedDate, LocalTime feedTime, String topic, int relevance,
	Developer developer, List<Response> responses, int totalComments) */
	
	/*public Response(int id, String answer, LocalDate respDate, LocalTime respTime, int accuracy, Developer developer,
			Feed feed)*/
	
	/*public Developer(Long devId, String name, String email, String skillLevel, LocalDate memberSince, Users users,
			List<Feed> feeds, int totalFeeds, int reputation, boolean isVerified, boolean isBlocked) */

	
	 @Test
	    public void testGetAllDeveloper() {
		 	Users u1=new Users("Sravya123","Sravya@123","admin");
			LocalDate date = LocalDate.of(2020, 11, 12);
			LocalTime time=LocalTime.of(23, 50, 00);
			List<Feed> fs=new ArrayList<Feed>();
			List<Response> rs=new ArrayList<Response>();
			Developer d1=new Developer(53, "Sravya","sravya@123","Beginner",date,u1,fs,12,4,true,true);
			Feed f1=new Feed(54, "java",date,time,"DBMS",4,d1,rs,8);
			Response r1=new Response(55,"Javascript",date,time,6,d1,f1);
			fs.add(f1);
			rs.add(r1);
			
			List<Developer> developer=new ArrayList<Developer>();
			developer.add(d1);
			Mockito.when(devSer.getAllDeveloper()).thenReturn(developer);
	        assertEquals(developer,devSer.getAllDeveloper());

	    }
	 @Test
	 public void testDeveloperById() {
		 	Users u1=new Users("Sravya123","Sravya@123","admin");
			LocalDate date = LocalDate.of(2020, 11, 12);
			LocalTime time=LocalTime.of(23, 50, 00);
			List<Feed> fs=new ArrayList<Feed>();
			List<Response> rs=new ArrayList<Response>();
			Developer d1=new Developer(53, "Sravya","sravya@123","Beginner",date,u1,fs,12,4,true,true);
			Feed f1=new Feed(54, "java",date,time,"DBMS",4,d1,rs,8);
			Response r1=new Response(55,"Javascript",date,time,6,d1,f1);
			fs.add(f1);
			rs.add(r1);
		 
			Optional<Developer> developer =Optional.of(d1);
			int id=53;
			Mockito.when(devSer.getDeveloperById(id)).thenReturn(developer);
	        assertEquals(developer,devSer.getDeveloperById(id));
	 }
	 
	 
	 @Test
	 public void testaddDeveloper() {
		 	Users u1=new Users("Appu123","Appu@123","admin");
			LocalDate date = LocalDate.now();
			LocalTime time=LocalTime.now();
			List<Feed> fs=new ArrayList<Feed>();
			List<Response> rs=new ArrayList<Response>();
			Developer d1=new Developer("Apoorva","Appu@123","Beginner",date,u1,fs,12,4,true,true);
			Feed f1=new Feed("Python",date,time,"Tkinter",4,d1,rs,8);
			Response r1=new Response("HTML",date,time,6,d1,f1);
			fs.add(f1);
			rs.add(r1);
		
			Mockito.when(devSer.addDeveloper(d1)).thenReturn(d1);
	        assertEquals(d1,devSer.addDeveloper(d1));
	 }
	 
	 @Test
	 public void testupdateDeveloper() {
		 	Users u1=new Users("Sravya123","Sravya@123","developer");
			LocalDate date = LocalDate.of(2020, 11, 12);
			LocalTime time=LocalTime.of(23, 50, 00);
			List<Feed> fs=new ArrayList<Feed>();
			List<Response> rs=new ArrayList<Response>();
			Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
			Feed f1=new Feed(54, ".NET",date,time,"DBMS",4,d1,rs,8);
			Response r1=new Response(55,"CSS",date,time,6,d1,f1);
			fs.add(f1);
			rs.add(r1);
			
			Mockito.when(devSer.updateDeveloper(d1)).thenReturn(d1);
	        assertEquals(d1,devSer.updateDeveloper(d1));
		 
	 }
	 @Test
	 public void testremoveDeveloper() {
		 	int id=53;
		 	String str1="Developer with 53 deleted Successfully";
		 	Users u1=new Users("Sravya123","Sravya@123","developer");
			LocalDate date = LocalDate.of(2020, 11, 12);
			LocalTime time=LocalTime.of(23, 50, 00);
			List<Feed> fs=new ArrayList<Feed>();
			List<Response> rs=new ArrayList<Response>();
			Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
			Feed f1=new Feed(54, ".NET",date,time,"DBMS",4,d1,rs,8);
			Response r1=new Response(55,"CSS",date,time,6,d1,f1);
			fs.add(f1);
			rs.add(r1);
	        assertEquals(str1,devSer.removeDeveloper(id));
	 }

}
