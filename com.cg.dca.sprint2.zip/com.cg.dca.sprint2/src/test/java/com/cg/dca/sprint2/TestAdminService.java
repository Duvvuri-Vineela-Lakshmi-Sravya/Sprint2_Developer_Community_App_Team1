package com.cg.dca.sprint2;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.stubbing.answers.DoesNothing;
import org.mockito.junit.jupiter.MockitoExtension;
import com.cg.dca.sprint2.model.Admin;
import com.cg.dca.sprint2.repository.IAdminRepository;
import com.cg.dca.sprint2.service.AdminService;



@ExtendWith(MockitoExtension.class)
public class TestAdminService 
{
	@Mock
	IAdminRepository adminRepository;

	@InjectMocks
	AdminService adminService;

	 @Test
	    public void testGetAllAdmin() {
		 Admin ad = new Admin(52,"Appu","Appu@1234");
	        List<Admin> admin=new ArrayList<Admin>();
	        admin.add(ad);
	       Mockito.when(adminService.getAllAdmin()).thenReturn(admin);
	        assertEquals(admin,adminService.getAllAdmin());

	    }
	 @Test
	 public void testAdminById() {
		 Admin admin = new Admin(52,"Appu","Appu@1234");
		 Optional<Admin> ads = Optional.of(admin); 
		 int id=52;
		 Mockito.when(adminService.getAdminById(id)).thenReturn(ads);
	        assertEquals(ads,adminService.getAdminById(id));
	 }
	 
	 @Test
	 public void testaddAdmin() {
		Admin a1=new Admin("Sravya","Srav@123");
		 Mockito.when(adminService.addAdmin(a1)).thenReturn(a1);
	        assertEquals(a1,adminService.addAdmin(a1));
	 }
	 
	@Test
	 public void testupdateAdmin() {
		 Admin ad1=new Admin("Sonu","Srav@123");
		 Mockito.when(adminService.updateAdmin(ad1)).thenReturn(ad1);
	        assertEquals(ad1,adminService.addAdmin(ad1));
		 
	 }
	@Test
	 public void testdeleteAdmin() {
		 String str1="Admin with 52 deleted successfully";
		 int id=52;
	     assertEquals(str1,adminService.deleteAdminbyId(id));
	 }

}