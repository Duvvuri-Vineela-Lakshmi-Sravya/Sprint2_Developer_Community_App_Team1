package com.cg.dca.sprint2;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.dca.sprint2.control.ResponseControl;
import com.cg.dca.sprint2.model.Developer;
import com.cg.dca.sprint2.model.Feed;
import com.cg.dca.sprint2.model.Response;
import com.cg.dca.sprint2.model.Users;
import com.cg.dca.sprint2.repository.IResponseRepository;
import com.cg.dca.sprint2.service.ResponseService;



@ExtendWith(MockitoExtension.class)
	public class TestResponseService{
	    
		@InjectMocks
		ResponseService respSer;
		

		@Mock
		IResponseRepository respRep;

		 @Test
		    public void testGetAllResponses() {
			 	Users u1=new Users("Sravya123","Sravya@123","admin");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravya","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, "java",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"Javascript",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
				
		       Mockito.when(respSer.getAllresponses()).thenReturn(rs);
		        assertEquals(rs,respSer.getAllresponses());

		    }
		 @Test
		 public void testResponseById() {
			 	Users u1=new Users("Sravya123","Sravya@123","admin");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravya","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, "java",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"Javascript",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
				int id=55;	
				Optional<Response> res = Optional.of(r1);
				Mockito.when(respSer.getResponseById(id)).thenReturn(res);
		        assertEquals(res,respSer.getResponseById(id));
			 
		 }
		 @Test
		 public void testaddResponse() {
			 Users u1=new Users("Sravya123","Sravya@123","admin");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravya","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, "java",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response("Hadoop",date,time,8,d1,f1);
				fs.add(f1);
				rs.add(r1);
				Mockito.when(respSer.addresponse(r1)).thenReturn(r1);
		        assertEquals(r1,respSer.addresponse(r1));
			 
		 }
		 @Test
		 public void testupdateResponse() {
			Users u1=new Users("Sravya123","Sravya@123","admin");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravya","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, "java",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"Cloud Computing",date,time,8,d1,f1);
				fs.add(f1);
				rs.add(r1);
				Mockito.when(respSer.updateResponse(r1)).thenReturn(r1);
		        assertEquals(r1,respSer.updateResponse(r1));
			 
		 }
		 @Test
		 public void testremoveResponse() {
			 String str1= "Response with 55 deleted Sucessfully";
			 int id=55;
		     assertEquals(str1,respSer.removeResponse(id));
		 }

}