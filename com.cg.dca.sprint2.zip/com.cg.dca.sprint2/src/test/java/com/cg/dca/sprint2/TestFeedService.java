package com.cg.dca.sprint2;

import static org.junit.Assert.assertEquals;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import com.cg.dca.sprint2.model.Developer;
import com.cg.dca.sprint2.model.Feed;
import com.cg.dca.sprint2.model.Response;
import com.cg.dca.sprint2.model.Users;
import com.cg.dca.sprint2.repository.IFeedRepository;
import com.cg.dca.sprint2.service.FeedService;



	@ExtendWith(MockitoExtension.class)
	public class TestFeedService
	{
	    
		@Mock
		IFeedRepository feedRepository;
		
		@InjectMocks
		FeedService feedService;

		 @Test
		    public void testGetAllFeeds() {
			 Users u1=new Users("Sravya123","Sravya@123","developer");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, ".NET",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"CSS",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
		       Mockito.when(feedService.getAllfeeds()).thenReturn(fs);
		        assertEquals(fs,feedService.getAllfeeds());

		    }
		 @Test
		 public void testFeedByTopic() {
			 Users u1=new Users("Sravya123","Sravya@123","developer");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, ".NET",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"CSS",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
				String topic="java";
				List<Feed> li = feedService.getFeedByTopic(topic);
				Mockito.when(feedService.getFeedByTopic(topic)).thenReturn(li);
		        assertEquals(li,feedService.getFeedByTopic(topic));
			 
		 }
		 @Test
		 public void testFeedByKeyword() {
			 Users u1=new Users("Sravya123","Sravya@123","developer");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, ".NET",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"CSS",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
				String keyword="java";
				List<Feed> li = feedService.getFeedByKeyword(keyword);
				Mockito.when(feedService.getFeedByKeyword(keyword)).thenReturn(li);
		        assertEquals(li,feedService.getFeedByKeyword(keyword));
		 }
		 @Test
		 public void testaddFeed()
		 {
			 LocalDate date = LocalDate.of(2020, 11, 12);
			 LocalTime time=LocalTime.of(23, 50, 00);
			 LocalDate feedDate = LocalDate.now();
			 LocalTime feedTime = LocalTime.now();
			 Users u1=new Users("Sravya123","Sravya@123","developer");
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, "java",feedDate,feedTime,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"CSS",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
				Mockito.when(feedService.addfeed(f1)).thenReturn(f1);
		        assertEquals(f1,feedService.addfeed(f1));
			 
		 }
		 @Test
		 public void testupdateFeed() {
			 LocalDate date = LocalDate.of(2020, 11, 12);
			 LocalTime time=LocalTime.of(23, 50, 00);
			 LocalDate feedDate = LocalDate.now();
			 LocalTime feedTime = LocalTime.now();
			 Users u1=new Users("Sravya123","Sravya@123","developer");
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, "java",feedDate,feedTime,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"CSS",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
		    Mockito.when(feedService.updateFeed(f1)).thenReturn(f1);
		        assertEquals(f1,feedService.updateFeed(f1));
			 
		 }
		 @Test
		 public void testremoveFeed() 
		 {
			 	Users u1=new Users("Sravya123","Sravya@123","developer");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, ".NET",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"CSS",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
				String str1= "Feed with 54 deleted Sucessfully";
				int id=54;
		        assertEquals(str1,feedService.removeFeed(id));
		 }
		 @Test
		 public void testgetFeedById()
		 {
			 Users u1=new Users("Sravya123","Sravya@123","developer");
				LocalDate date = LocalDate.of(2020, 11, 12);
				LocalTime time=LocalTime.of(23, 50, 00);
				List<Feed> fs=new ArrayList<Feed>();
				List<Response> rs=new ArrayList<Response>();
				Developer d1=new Developer(53, "Sravyaa","sravya@123","Beginner",date,u1,fs,12,4,true,true);
				Feed f1=new Feed(54, ".NET",date,time,"DBMS",4,d1,rs,8);
				Response r1=new Response(55,"CSS",date,time,6,d1,f1);
				fs.add(f1);
				rs.add(r1);
				Optional<Feed> feeds = Optional.of(f1);
				int id=54;
				Mockito.when(feedService.getFeedById(id)).thenReturn(feeds);
		        assertEquals(feeds,feedService.getFeedById(id));
		 }
}
