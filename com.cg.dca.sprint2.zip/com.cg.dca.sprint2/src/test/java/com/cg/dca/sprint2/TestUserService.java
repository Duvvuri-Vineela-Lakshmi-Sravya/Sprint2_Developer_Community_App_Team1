package com.cg.dca.sprint2;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.dca.sprint2.model.Users;
import com.cg.dca.sprint2.repository.IUserRepository;
import com.cg.dca.sprint2.service.UserService;



@ExtendWith(MockitoExtension.class)
public class TestUserService {
	
	@InjectMocks
	UserService userSer;
	
	@Mock
	IUserRepository userRep;
	
	
	@Test
    public void testGetAllUser() {
        List<Users> user=new ArrayList<Users>();
        user.add(new Users("Sravya123","Sravya@123","Admin"));
        user.add(new Users("Venky234","Venky@0522","admin"));
        Mockito.when(userSer.getAllUsers()).thenReturn(user);
        assertEquals(user,userSer.getAllUsers());

    }
	
	@Test
	 public void testinsertUser() {
		Users u1=new Users("Appu123","appu@1972","developer");
		userSer.addUser(u1);
	    assertEquals("Appu123",u1.getUserId()); 
	 }
	
	 
	 @Test
	 public void testupdateUser() {
		Users u1=new Users("Appu123","Radha@1972","admin");
		 Mockito.when(userSer.updateUser(u1)).thenReturn(u1);
	        assertEquals(u1,userSer.updateUser(u1));		 
	 }
	 
	 @Test
	 public void testdeleteUser() {
		 String str1= "user with Appu123 deleted successfully";
		 String id="Appu123";
	     assertEquals(str1,userSer.deleteUser(id));
	 }
	 
	 
	 @Test
	 public void login() {
		 Users u1=new Users("Sravya123","Sravya@123","Admin");
		 String str1= userSer.login(u1);
		 //Mockito.when(userSer.login(u1)).thenReturn(str1);
	        assertEquals(str1,userSer.login(u1));
	 }
	 
	 @Test
	 public void logout() {
		 Users user=new Users("Venky234","Venky@0522","admin");
		 String str1= "Venky234 has successfully logged out";
		 Mockito.when(userSer.logout(user)).thenReturn(str1);
	        assertEquals(str1,userSer.logout(user));
	 }

}